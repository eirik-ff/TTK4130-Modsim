function [ state_dot ] = SatelliteDynamics( t, x, parameters )

    % Code your equations here...

    % The code must return in the order you selected, e.g.:
    %    state_dot =  [velocity;
    %                  orientation_dot;
    %                  acceleration (ac);
    %                  angular acceleration (omega dot)];

end
